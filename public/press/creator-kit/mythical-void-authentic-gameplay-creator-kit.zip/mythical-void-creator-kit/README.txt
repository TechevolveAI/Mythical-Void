MYTHICAL VOID — AUTHENTIC GAMEPLAY CREATOR KIT
=================================================

Mythical Void is a free early-access creature adventure from an independent Irish studio. It began as a father-and-son experiment to see what imagination and generative AI tools could make possible, and grew into a real browser game.

PLAY THE GAME
https://mythicalvoid.com/playable-now/

WHAT IS IN THIS PACKAGE
- Three silent videos: vertical, square and wide.
- Three matching poster images.
- A caption pack with checked wording and useful alternative text.
- The official Mythical Void emblem.
- A plain-text fact sheet.
- A checklist for an official Mythical Void channel release.
- PACKAGE_MANIFEST.json, which records every included file.

MEDIA TRUTH
The complete moving game frame in each video is real Mythical Void gameplay recorded from the running browser game. The surrounding branded layout is not gameplay. No generated motion, replacement scenery, replacement interface or replacement audio was added.

SAFE EDITORIAL USE
Adults, journalists and creators may use these assets for truthful coverage of Mythical Void when the media truth above is kept clear. Do not describe the branded layout as raw gameplay. Do not imply that NASA endorses Mythical Void. Do not claim that every creature is globally unique, sentient or conscious.

CHILD SAFEGUARDING
The studio story may say that Mythical Void began as a father-and-son project. Do not publish the child's exact age or add a child's name, photograph, quotation, contact route or identifying detail. Do not invite children to contact the studio directly.

OFFICIAL MYTHICAL VOID POSTS
Publishing through an official Mythical Void social account still requires Kevin's approval. Follow OFFICIAL_CHANNEL_RELEASE_CHECKLIST.txt before an official post.
