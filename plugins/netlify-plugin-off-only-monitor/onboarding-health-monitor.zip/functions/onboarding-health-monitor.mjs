
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// output/onboarding-metrics-v1/runtime-operations-v1/monitor-core.cjs
var require_monitor_core = __commonJS({
  "output/onboarding-metrics-v1/runtime-operations-v1/monitor-core.cjs"(exports, module) {
    "use strict";
    var HOUR = 36e5;
    var OUTER = "core,job_configured,last_job_started_at,last_job_status,schema_version";
    var INNER = "activated_on,checked_at,collection_enabled,last_retention_run,privacy_review_approved,schema_version";
    function assess(value, now = Date.now()) {
      const fail = (category) => ({ healthy: false, category });
      if (!value || Object.keys(value).sort().join(",") !== OUTER || value.schema_version !== 1 || typeof value.job_configured !== "boolean") return fail("invalid_status");
      const c = value.core;
      if (!c || Object.keys(c).sort().join(",") !== INNER || c.schema_version !== 1 || typeof c.collection_enabled !== "boolean" || typeof c.privacy_review_approved !== "boolean") return fail("invalid_status");
      if (c.collection_enabled || c.privacy_review_approved || c.activated_on !== null) return fail("unexpected_activation");
      const checked = typeof c.checked_at === "string" ? Date.parse(c.checked_at) : NaN;
      const pruned = typeof c.last_retention_run === "string" ? Date.parse(c.last_retention_run) : NaN;
      if (!Number.isFinite(now) || !Number.isFinite(checked) || checked > now + 6e4 || now - checked > 3e5) return fail("invalid_status");
      if (!Number.isFinite(pruned) || pruned > now) return fail("retention_unknown");
      if (!value.job_configured) return fail("schedule_missing");
      if (now - pruned >= 26 * HOUR) return fail("retention_lockout");
      if (now - pruned >= 25 * HOUR) return fail("retention_warning");
      if (value.last_job_status === null) {
        if (value.last_job_started_at !== null) return fail("invalid_status");
      } else {
        const start = typeof value.last_job_started_at === "string" ? Date.parse(value.last_job_started_at) : NaN;
        if (!Number.isFinite(start) || start > now + 6e4) return fail("invalid_status");
        if (value.last_job_status === "failed") return fail("retention_failed");
        if (!["succeeded", "running", "starting", "connecting", "sending"].includes(value.last_job_status)) return fail("invalid_status");
        if (value.last_job_status !== "succeeded" && now - start > 12e4) return fail("retention_stuck");
      }
      return { healthy: true, category: value.last_job_status === null ? "bootstrap_schedule_pending" : "healthy" };
    }
    function pingURL(raw, healthy) {
      const u = new URL(raw);
      if (u.protocol !== "https:" || u.hostname !== "hc-ping.com" || u.port || u.username || u.password || u.search || u.hash || !/^\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(u.pathname)) throw Error("Invalid monitor destination");
      return u.href + (healthy ? "" : "/fail");
    }
    async function run({ readHealth, ping, now = () => Date.now() }) {
      let status;
      try {
        status = assess(await readHealth(), now());
      } catch {
        status = { healthy: false, category: "database_unavailable" };
      }
      try {
        await ping(status.healthy);
      } catch {
        return { healthy: false, category: "heartbeat_unavailable" };
      }
      return status;
    }
    module.exports = { assess, pingURL, run };
  }
});

// output/onboarding-metrics-v1/runtime-operations-v1/functions/onboarding-health-monitor.mjs
var import_monitor_core = __toESM(require_monitor_core(), 1);
import pg from "pg";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
var EXPECTED_PROJECT = "mkcmdbzcihjgidjuypqe";
var config = { schedule: "*/15 * * * *" };
function connectionOptions(raw, ca) {
  const u = new URL(raw);
  const user = decodeURIComponent(u.username);
  const destination = u.hostname === `db.${EXPECTED_PROJECT}.supabase.co` && user === "onboarding_monitor" || u.hostname.endsWith(".pooler.supabase.com") && user === `onboarding_monitor.${EXPECTED_PROJECT}`;
  if (!["postgres:", "postgresql:"].includes(u.protocol) || !destination || u.pathname !== "/postgres" || !u.password || u.search || u.hash) throw Error("Invalid monitor connection");
  return {
    host: u.hostname,
    port: Number(u.port || 5432),
    user,
    password: decodeURIComponent(u.password),
    database: "postgres",
    ssl: { ca, rejectUnauthorized: true },
    connectionTimeoutMillis: 5e3,
    query_timeout: 6e3,
    statement_timeout: 5e3,
    application_name: "mythical-onboarding-health",
    options: "-c default_transaction_read_only=on -c statement_timeout=5000"
  };
}
async function onboarding_health_monitor_default() {
  if (process.env.ONBOARDING_MONITOR_ENABLED !== "true") {
    console.log(JSON.stringify({ service: "onboarding-maintenance", category: "disabled" }));
    return;
  }
  let url;
  try {
    url = import_monitor_core.default.pingURL(process.env.ONBOARDING_HEALTHCHECK_URL, true);
  } catch {
    console.log(JSON.stringify({ service: "onboarding-maintenance", category: "configuration_missing" }));
    return;
  }
  const result = await import_monitor_core.default.run({
    readHealth: async () => {
      const ca = readFileSync(fileURLToPath(new URL("../supabase-ca.pem", import.meta.url)), "utf8");
      const client = new pg.Client(connectionOptions(process.env.ONBOARDING_MONITOR_DATABASE_URL, ca));
      client.on("error", () => {
      });
      try {
        await client.connect();
        await client.query("begin read only");
        const { rows } = await client.query("select onboarding_ops.read_health() as health");
        await client.query("rollback");
        if (rows.length !== 1) throw Error("Missing health status");
        return rows[0].health;
      } finally {
        await client.end().catch(() => {
        });
      }
    },
    ping: async (healthy) => {
      const response = await fetch(import_monitor_core.default.pingURL(url, healthy), { method: "GET", redirect: "error", signal: AbortSignal.timeout(4e3), headers: { "User-Agent": "MythicalVoid-Onboarding-Health/1" } });
      if (!response.ok) throw Error("Heartbeat not accepted");
      await response.body?.cancel();
    }
  });
  console.log(JSON.stringify({ service: "onboarding-maintenance", ...result }));
}
export {
  config,
  connectionOptions,
  onboarding_health_monitor_default as default
};
